import React, { Component } from 'react'
import jwt_decode from 'jwt-decode'
import Jobs from './jobs'

class Profile extends Component {
    constructor() {
        super()
        this.state = {
            first_name: '',
            last_name: '',
            phone_no: ''
        }
    }

    componentDidMount() {
        const token = localStorage.usertoken
        const decoded = jwt_decode(token)
        this.setState({
            first_name: decoded.first_name,
            last_name: decoded.last_name,
            phone_no: decoded.phone_no
        })
    }

    render() {
        return (
            <div className="container">
                <div className="jumbotron mt-5">
                    <div className="col-sm-8 mx-auto">
                        <h1 className="text-center">Welcome to the HomePage</h1>
                    </div>
                    <table className="table col-md-6 mx-auto">
                        <tbody>
                            <tr>
                                <td>First Name</td>
                                <td>{this.state.first_name}</td>
                            </tr>
                            <tr>
                                <td>Last Name</td>
                                <td>{this.state.last_name}</td>
                            </tr>
                            <tr>
                                <td>phone_no</td>
                                <td>{this.state.phone_no}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div>
                    <Jobs />
                </div>
            </div>
        )
    }
}

export default Profile